﻿using AMP.Administration.Service.Model;
using AMP.Administration.Service.RepositoryContract;
using Weir.AMP.Core.DataAccess.Repository;

namespace AMP.Administration.Repository.RepositoryImplementation
{
    public class AMPRepository : RepositoryBase, IAMPRepository
    {

        public AMPRepository(ServiceDbContext dbContext)
                    : base(dbContext)
        {

        }
    }
}
