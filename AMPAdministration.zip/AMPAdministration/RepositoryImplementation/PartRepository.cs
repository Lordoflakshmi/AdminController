﻿using AMP.Administration.Service.DTO.Response;
using AMP.Administration.Service.Model;
using AMP.Administration.Service.RepositoryContract;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AMP.Administration.Service.RepositoryImplementation
{
    public class PartRepository : IPartRepository
    {
        private readonly ServiceDbContext serviceDbContext;
        public PartRepository(ServiceDbContext dbContext)
        {
            this.serviceDbContext = dbContext;
        }
        
        public async Task<List<ProcPartComponentRuleDetail>> GetComponentRuleDetailsForClearanceOrTorqueAsync(string partNumber, int customerId, int manufacturerId)
        {
            SqlParameter pCustomerId = new SqlParameter("@CustomerId", customerId );
            SqlParameter pPartNumber = new SqlParameter("@PartNumber", partNumber);
            SqlParameter pManufacturerId = new SqlParameter("@ManufacturerId", manufacturerId);
            var result = await serviceDbContext.ProcPartComponentRuleDetail.FromSqlRaw("EXEC procPump1WorkOrderAssetGetInspectionRuleDetails  @CustomerId, @PartNumber, @ManufacturerId", pCustomerId, pPartNumber, pManufacturerId).ToListAsync();
            return result;
        }
    }
}
