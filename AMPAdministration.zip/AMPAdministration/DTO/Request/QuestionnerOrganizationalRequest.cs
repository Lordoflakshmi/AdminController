﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AMP.Administration.Service.DTO.Request
{
   public class QuestionnerOrganizationalRequest
    {
        public long? AreaId { get; set; }
        public long? RegionId { get; set; }
        public long? DistrictId { get; set; }
        public long? GroupId { get; set; }
    }
}
