﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AMP.Administration.Service.DTO.Response
{
   public class GaugeResponse
    {
        public int Id { get; set; }
        public string GaugeId { get; set; }
        //public string GuageTypeName { get; set; }
    }
}
