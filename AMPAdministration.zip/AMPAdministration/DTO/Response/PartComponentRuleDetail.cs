﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AMP.Administration.Service.DTO.Response
{
    public class PartComponentRuleDetail
    {
        public int BearingNumber { get; set; }
        public decimal MinimumValue { get; set; }
        public decimal MaximumValue { get; set; }
    }
}
