﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AMP.Administration.Service.DTO.Response
{
    public class OrganizationalGroupHeirarchyNameResponse
    {
        public string OrganizationName { get; set; }
        public string CustomerName { get; set; }
        public string AreaName { get; set; }
        public string RegionName { get; set; }
        public string DistrictName { get; set; }
        public string GroupName { get; set; }
    }
}
