﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AMP.Administration.Service.DTO.Response
{
    public class Response
    {
        public string Message { get; set; }
        public object Content { get; set; }
        public bool status { get; set; }
    }
}
