﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AMP.Administration.Service.DTO.Response
{
    public class LocationResponse
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public int LocationHierarchyLevelId { get; set; }
    }
}
