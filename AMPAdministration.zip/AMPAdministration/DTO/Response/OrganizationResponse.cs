﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AMP.Administration.Service.DTO.Response
{
   public class OrganizationResponse
    {
        public long Id { get; set; }
        public string Name { get; set; }
        public int? LevelId { get; set; }
        //public string OrganizationalGroupLevelName { get; set; }
    }
}
