﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AMP.Administration.Service.DTO.Response
{
   public class ImageResponse
    {
        public int Id { get; set; }
        public string UploadedImage { get; set; }
    }
}
