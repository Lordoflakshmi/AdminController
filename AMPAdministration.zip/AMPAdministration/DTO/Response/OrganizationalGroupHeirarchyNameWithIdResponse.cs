﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AMP.Administration.Service.DTO.Response
{
    public class OrganizationalGroupHeirarchyNameWithIdResponse
    {

        public long? orgGroupId { get; set; }
        public long? OrganizationId { get; set; }
        public string OrganizationName { get; set; }
        public long? CompanyId { get; set; }
        public string CompanyName { get; set; }
        public long? AreaId { get; set; }
        public string AreaName { get; set; }
        public long? RegionId { get; set; }
        public string RegionName { get; set; }
        public long? DistrictId { get; set; }
        public string DistrictName { get; set; }
        public long? GroupId { get; set; }
        public string GroupName { get; set; }
    }
}
