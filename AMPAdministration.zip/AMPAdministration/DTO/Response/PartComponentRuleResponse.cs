﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AMP.Administration.Service.DTO.Response
{
    public class PartComponentRuleResponse
    {
        public string SpecBook { get; set; }
        public string RuleName { get; set; }
        public List<PartComponentRuleDetail> RuleDetails { get; set; }
    }
}
