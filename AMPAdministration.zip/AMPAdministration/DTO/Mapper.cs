﻿using AMP.Administration.Service.DTO.Response;
using AMP.Administration.Service.Model;
using AutoMapper;
using System;
using System.Collections.Generic;
using System.Text;

namespace AMP.Administration.Service.DTO
{
    public class MapperProfile : Profile
    {
        public MapperProfile()
        {
            CreateMap<PartMaster, ImageResponse>()
               .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.PartTypeId))
               .ForMember(dest => dest.UploadedImage, opt => opt.MapFrom(src => src.DrawingImage));
        }
    }
}
