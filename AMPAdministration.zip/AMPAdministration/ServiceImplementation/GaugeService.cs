﻿using AMP.Administration.Service.DTO.Response;
using AMP.Administration.Service.Model;
using AMP.Administration.Service.RepositoryContract;
using AMP.Administration.Service.ServiceContract;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace AMP.Administration.Service.ServiceImplementation
{
   public  class GaugeService: IGauge
    {
        private readonly IAMPRepository ampRepository;
        public GaugeService(IAMPRepository _ampRepository)
        {
            this.ampRepository = _ampRepository;
        }

        #region public async Task<Response> GetGaugesByServiceCenterId(int GaugeId, long ServiceCenterId)
        public async Task<Response> GetGaugesByServiceCenterId(int GaugeId, long ServiceCenterId)
        {
            var response = new Response() { Message = "Retrieved Successfully.", status = true };
            var GaugeTypeResponse = new List<GaugeResponse>();
            if (GaugeId != 0)
            {
                var GetGaugeTypes = await ampRepository.Query<Gauge>().Where(a => a.GaugeTypeId == GaugeId && (ServiceCenterId == 0 || a.LocationId == Convert.ToInt32(ServiceCenterId)) &&a.IsActive==true)
                   .Join(ampRepository.Query<GaugeType>(), a => a.GaugeTypeId, g => g.GaugeTypeId, (a, b) => new { a, b })
                         .Select(e => new GaugeResponse
                         {
                             Id = e.a.Id,
                             GaugeId = e.a.GaugeId, 
                         }).ToListAsync();
                if (GetGaugeTypes.Count == 0)
                {
                    response.Message = "Data doesn't exist";
                    response.status = false;
                }
                else
                {
                    response.Content = GetGaugeTypes;
                    response.Message = "Retrieved Successfully.";
                    response.status = true;
                }
            }

            else
            {
                response.Message = "ServiceCenterId doesn't exist. Please use correct ServiceCenterId.";
                response.status = false;
            }
            return response;
        }
        #endregion

        #region public async Task<Response> GetGaugeTypeByGaugeIdAsync(int[] gaugeIds)
        public async Task<Response> GetGaugeTypeByGaugeIdAsync(int[] gaugeIds)
        {
            var response = new Response() { Message = "Retrieved Successfully.", status = true };
            var GaugeTypeResponse = new List<GaugeResponse>();
            var GetGaugeTypes = await ampRepository.Query<Gauge>()
                .Where(a => gaugeIds.Contains(a.Id))
                .Select(e => new 
                {
                    Id = e.Id,
                    Name = e.GaugeId,
                }).ToListAsync();

            response.Content = GetGaugeTypes;

            return response;
        }
        #endregion
    }
}
