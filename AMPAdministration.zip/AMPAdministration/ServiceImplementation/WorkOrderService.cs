﻿using AMP.Administration.Service.DTO.Response;
using AMP.Administration.Service.Model;
using AMP.Administration.Service.RepositoryContract;
using AMP.Administration.Service.ServiceContract;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AMP.Administration.Service.ServiceImplementation
{
    public class WorkOrderService : IWorkOrder
    {
        private readonly IAMPRepository ampRepository;

        public WorkOrderService(IAMPRepository _ampRepository)
        {
            this.ampRepository = _ampRepository;
        }
        public async Task<Response> GetWorkOrderType()
        {
            var workOrderType = await ampRepository.Query<WorkOrderType>()
                    .Where(e => e.IsPumpWorkOrderType && e.IsActive)
                    .Select(r => new ValueResponse()
                    {
                        Id = r.Id.ToString(),
                        Value = r.Name
                    })
                    .ToListAsync();

            return new Response() { Content = workOrderType };
        }
    }
}
