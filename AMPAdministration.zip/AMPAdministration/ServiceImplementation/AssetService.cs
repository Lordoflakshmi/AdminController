﻿using AMP.Administration.Service.DTO.Response;
using AMP.Administration.Service.Model;
using AMP.Administration.Service.RepositoryContract;
using AMP.Administration.Service.ServiceContract;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AMP.Administration.Service.ServiceImplementation
{
   public class AssetService :IAsset
    {
        private readonly IAMPRepository ampRepository;
        public AssetService(IAMPRepository _ampRepository)
        {
            this.ampRepository = _ampRepository;
        }
        #region Task<Response> GetStatusNameByIds
        public async Task<Response> GetStatusNameByIds(int[] StatusIds)
        {
            var result = await ampRepository.Query<AssetStatus>().Where(x => StatusIds.Contains(x.AssetStatusId) && x.IsActive == true).Select(m => new
            {
                m.Name,
                Id = m.AssetStatusId
            }).ToListAsync();
            return new Response() { Content = result, status = true };
        }
        #endregion
    }
}
