﻿using AMP.Administration.Service.DTO.Response;
using AMP.Administration.Service.Helpers;
using AMP.Administration.Service.Model;
using AMP.Administration.Service.RepositoryContract;
using AMP.Administration.Service.ServiceContract;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AMP.Administration.Service.ServiceImplementation
{
   public  class PartImageService: IPartImage
    {
        private readonly IAMPRepository ampRepository;
        private readonly IMapper mapper;

        public PartImageService(IAMPRepository _ampRepository, IMapper _mapper)
        {
            this.ampRepository = _ampRepository;
            this.mapper = _mapper;
        }
        public async Task<Response> GetPictureByIdsAsync(int PartTypeId, int PressureRatingId, int ServiceId, int SizeId, int StyleId, int VariationId)
        {
            var response = new Response();
            
            if (PartTypeId!=0&&PressureRatingId!=0&&ServiceId!=0&&SizeId!=0&&StyleId!=0&&VariationId!=0)
            {
                var image = await ampRepository.Query<PartMaster>()
                    .SingleOrDefaultAsync(e => e.PartTypeId == PartTypeId && e.PressureRatingId==PressureRatingId&&
                    e.ServiceId==ServiceId&&e.SizeId==SizeId&&e.StyleId==StyleId&&e.VariationId==VariationId);

                if (image != null && image.DrawingImage != null)
                {
                    //  var receivingPicture =mapper.Map<ImageResponse>(image);
                    ImageResponse receivingPicture = new ImageResponse();
                    receivingPicture.Id = image.PartTypeId;
                    string[] queryIds = image.DrawingName.Split(".");
                    receivingPicture.UploadedImage = string.Format("data:image/" + queryIds[1] + ";base64,{0}", Convert.ToBase64String(image.DrawingImage));
                    response.Content = receivingPicture;
                    response.Message = AdministrationMessages.GetSuccess;
                    response.status = true;
                }
                else
                {
                    response.Message = AdministrationMessages.PictureUnavailable;
                    response.status = false;
                }
            }
            else
            {
                response.Message = AdministrationMessages.InvalidData;
                response.status = false;
            }

            return response;

        }
    }
}
