﻿using AMP.Administration.Service.DTO.Response;
using AMP.Administration.Service.Model;
using AMP.Administration.Service.RepositoryContract;
using AMP.Administration.Service.ServiceContract;
using Common.Helpers;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AMP.Administration.Service.ServiceImplementation
{
    public class InspectionService : IInspection
    {
        private readonly IAMPRepository ampRepository;

        public InspectionService(IAMPRepository _ampRepository)
        {
            this.ampRepository = _ampRepository;
        }

        #region GetInspectionType
        public async Task<Response> GetInspectionType()
        {            
            var inspectionTypeDetails = await ampRepository.Query<InspectionLevel>().Where(a => a.Name == "Pump - Level 1" || a.Name ==  "Pump - Level 2" || a.Name == "OPM Inspection")
                    .Join(ampRepository.Query<InspectionLevelType>(), il => il.InspectionLevelId, ilt => ilt.InspectionLevelId, (il, ilt) => new {ilt.InspectionTypeId})
                    .Join(ampRepository.Query<InspectionType>(), ilt => ilt.InspectionTypeId, it => it.InspectionTypeId, (ilt, it) => new {it.InspectionTypeId, it.Name  })
                    .Select(r => new ValueResponse()
                    {
                        Id = r.InspectionTypeId.ToString(),
                        Value = r.Name
                    })
                    .Distinct()
                    .ToListAsync();

            return new Response() { Message=Messages.GetSuccess, status= true, Content = inspectionTypeDetails };
        }
        #endregion
    }
}
