﻿using AMP.Administration.Service.DTO.Response;
using AMP.Administration.Service.Model;
using AMP.Administration.Service.RepositoryContract;
using AMP.Administration.ServiceContract;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AMP.Administration.Service
{
    public class LocationService : ILocation
    {
        private readonly IAMPRepository ampRepository;
        public LocationService(IAMPRepository _ampRepository)
        {
            this.ampRepository = _ampRepository;
        }

        #region public async Task<Response> GetLocations(long requestedById)
        public async Task<Response> GetLocations(long requestedById)
        {
            var response = new Response() { status = true };
            var serviceCentres = new List<LocationResponse>();

            var userLocations = await ampRepository.Query<UserLocation>()
                .Join(ampRepository.Query<Location>(), ul => ul.LocationId, l => l.LocationId, (ul, l) => new { ul, l })
                .Where(e => e.ul.UserId == requestedById)
                .ToListAsync();

            var locationResponse = userLocations
                .Select(s => new LocationResponse()
                {
                    Id = s.l.LocationId.ToString(),
                    Name = s.l.LocationName,
                    LocationHierarchyLevelId = (int)Enums.LocationHierarchyLevel.Location
                })
                .ToList();

            serviceCentres.AddRange(locationResponse);

            var regions = userLocations.Select(s => s.l.LocationHierarchyId).Distinct().ToList();

            var regionResponse = await ampRepository.Query<LocationHierarchy>()
                .Join(ampRepository.Query<LocationHierarchyLevel>(), lh => lh.LocationHierarchyLevelId, lhl => lhl.LocationHierarchyLevelId, (lh, lhl) => new { lh, lhl })
                .Where(e => regions.Contains(e.lh.LocationHierarchyId))
                .Select(s => new LocationResponse()
                {
                    Id = s.lh.LocationHierarchyId.ToString(),
                    Name = s.lh.Name,
                    LocationHierarchyLevelId = s.lhl.LocationHierarchyLevelId
                })
                .ToListAsync();

            serviceCentres.AddRange(regionResponse);            

            response.Content = serviceCentres.OrderByDescending(e => e.LocationHierarchyLevelId);

            return response;
        }
        #endregion

        #region public async Task<Response> GetLocationsName(long[] ids)
        public async Task<Response> GetLocationsName(long[] ids)
        {
            var response = new Response() { status = true };
            var locationResponse = new List<LocationNameResponse>();

            var locations = await ampRepository.Query<Location>()
                .Where(x => ids.Contains(x.LocationId))
                .Select(m => new LocationNameResponse()
                {
                    Id = m.LocationId,
                    Name = m.LocationName,
                    LocationHierarchyLevelId = (int)Enums.LocationHierarchyLevel.Location
                }).ToListAsync();

            locationResponse.AddRange(locations);

            var regions = await ampRepository.Query<LocationHierarchy>()
                .Where(x => ids.Contains(x.LocationHierarchyId))
                .Select(m => new LocationNameResponse()
                {
                    Id = m.LocationHierarchyId,
                    Name = m.Name,
                    LocationHierarchyLevelId = m.LocationHierarchyLevelId
                }).ToListAsync();

            locationResponse.AddRange(regions);

            response.Content = locationResponse;
            return response;
        }
        #endregion

        #region public async Task<Response> GetTransferLocationsAsync(long serviceCenterId, int locationHierarchyLevelId, long requestedById)
        public async Task<Response> GetTransferLocationsAsync(long serviceCenterId, int locationHierarchyLevelId, long requestedById)
        {
            var response = new Response() { status = true };
            if((int)Enums.LocationHierarchyLevel.Region == locationHierarchyLevelId)
            {
                var userRegion = await ampRepository.Query<User>()
                    .Where(e => e.UserId == requestedById)
                    .Select(s => s).FirstOrDefaultAsync();

                var userRegions = userRegion.LocationId.Split(',').Select(int.Parse).ToList();
                
                var regions = await ampRepository.Query<LocationHierarchy>()
                    .Where(e => userRegions.Contains(e.LocationHierarchyId))
                    .Select(s => new 
                    {
                        Id = s.LocationHierarchyId,
                        Name = s.Name,
                        LocationHierarchyLevelId = s.LocationHierarchyLevelId
                    })
                    .ToListAsync();

                response.Content = regions;
            }

            else if((int)Enums.LocationHierarchyLevel.Location == locationHierarchyLevelId)
            {
                var location = await ampRepository.Query<Location>()
                    .Join(ampRepository.Query<LocationHierarchy>(), l => l.LocationHierarchyId, lh => lh.LocationHierarchyId, (l, lh) => new { l, lh })
                    .Where(e => e.l.LocationId == serviceCenterId)
                    .Select(s => new
                    {
                        Id = s.lh.LocationHierarchyId,
                        Name = s.lh.Name,
                        LocationHierarchyLevelId = s.lh.LocationHierarchyLevelId
                    })
                    .ToListAsync();

                response.Content = location;
            }

            return response;
        }
        #endregion

        #region public async Task<Response> GetIsNotificaionApplicable(long ids)
        public async Task<bool> GetIsNotificaionApplicable(long locationIds)
        {
            var response = new Response() { status = true };
            bool locations = await ampRepository.Query<Location>()
            .Where(x => x.LocationId == locationIds && x.IsNotificationApplicable == true)
            .Select(m => new
            {
                Id = m.LocationId
            }).AnyAsync();

            return locations;            
        }
        #endregion


    }
}

