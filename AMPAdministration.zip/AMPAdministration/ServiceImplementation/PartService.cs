﻿using AMP.Administration.Contract;
using AMP.Administration.Service.RepositoryContract;
using AMP.Administration.Service.Model;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json.Linq;
using System.Threading.Tasks;
using AMP.Administration.Service.DTO.Response;
using Microsoft.EntityFrameworkCore;
using System;
using Microsoft.Data.SqlClient;
using Common.Helpers;

namespace AMP.Administration.Service.ServiceImplementation
{
    public class PartService : IPart
    {
        private readonly IAMPRepository ampRepository;
        private readonly IPartRepository partRepository;
        public PartService(IAMPRepository _ampRepository, IPartRepository _partRepository)
        {
            this.ampRepository = _ampRepository;
            this.partRepository = _partRepository;
        }

        #region string GetPartTypeByPartNumber(string number)
        public string GetPartTypeByPartNumber(string number)
        {
            var part = ampRepository.Query<PartReference>().Where(a => a.PartNumber == number)
                .Join(ampRepository.Query<PartMaster>(), pr => pr.PartMasterId, pm => pm.PartMasterId, (pr, pm) => new { pm.PartTypeId })
                .Join(ampRepository.Query<PartType>(), j => j.PartTypeId, pt => pt.PartTypeId, (j, pt) => new { pt.Name }).Select(a => a.Name).SingleOrDefault();
            return part;
        }
        #endregion

        #region Response GetPartDetailsByPartNumber(string PartNumber)
        public Response GetPartDetailsByPartNumber(string PartNumber)
        {
            try
            {
                var part = ampRepository.Query<PartReference>().Where(a => a.PartNumber == PartNumber)
                  .Join(ampRepository.Query<PartMaster>(), pr => pr.PartMasterId, pm => pm.PartMasterId, (pr, pm) => new { pr.PartNumber, pm.PartTypeId, pm.SizeId, pm.ServiceId, pm.StyleId, pm.PressureRatingId, pm.VariationId })
                  .Join(ampRepository.Query<PartType>(), j => j.PartTypeId, pt => pt.PartTypeId, (j, pt) => new { j, pt }).Where(a => a.pt.IsPumpPartType == true)
                  .Join(ampRepository.Query<Size>(), r => r.j.SizeId, sz => sz.SizeId, (r, sz) => new { r, sz })
                  .Join(ampRepository.Query<Style>(), t => t.r.j.StyleId, st => st.StyleId, (t, st) => new { t, st })
                  .Join(ampRepository.Query<Model.Service>(), v => v.t.r.j.ServiceId, sr => sr.ServiceId, (v, sr) => new { v, sr })
                  .Join(ampRepository.Query<PressureRating>(), i => i.v.t.r.j.PressureRatingId, p => p.PressureRatingId, (i, p) => new { i, p })
                  .Join(ampRepository.Query<Variation>(), s => s.i.v.t.r.j.VariationId, d => d.VariationId, (s, d) => new { s, d })
                  .Select(m => new
                  {
                      m.s.i.v.t.r.j.PartNumber,
                      m.s.i.v.t.r.j.PartTypeId,
                      Partname = m.s.i.v.t.r.pt.Name,
                      m.s.i.v.t.r.j.SizeId,
                      SizeName = m.s.i.v.t.sz.Name,
                      m.s.i.v.t.r.j.StyleId,
                      StyleName = m.s.i.v.st.Name,
                      m.s.i.v.t.r.j.ServiceId,
                      ServiceName = m.s.i.sr.Name,
                      m.s.i.v.t.r.j.PressureRatingId,
                      PresureName = m.s.p.Value,
                      DesignationId = m.s.i.v.t.r.j.VariationId,
                      DesignationName = m.d.Name


                  }).FirstOrDefault();

                Response response = new Response
                {
                    status = true,
                    Content = part
                };
                if (part == null)
                {
                    response.Message = "No details exists";
                    response.status = false;
                }
                return response;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        #endregion

        #region async Task<Response> GetAllPartType()
        public async Task<Response> GetAllPartType()
        {
            var resp = await ampRepository.Query<PartType>().Where(x => x.IsActive == true &x.IsPumpPartType==true).Select(y => new
            {
                Id = y.PartTypeId,
                y.Name
            }).ToListAsync();

            return new Response()
            {
                Content = resp,
                status = true
            };
        }
        #endregion

        #region async Task<Response> GetPartConfigurations(long PartTypeId)
        public async Task<Response> GetPartConfigurations(long PartTypeId)
        {
            try
            {             
                var getsizes = await GetSizes(PartTypeId); 
                var getstyles = await GetStyles(PartTypeId);
                var getservices = await GetServices(PartTypeId); 
                var getpressureRatings =await GetPressureRatings(PartTypeId);
                var getDesignations = await GetDesignations(PartTypeId);

                var output = new Response()
                {
                    status = true,
                    Content = new
                    {
                        size = getsizes,
                        style = getstyles,
                        service = getservices,
                        pressureRating = getpressureRatings,
                        Designation= getDesignations
                    }
                };
                return output;
            }
            catch(Exception ex)
            {
                throw new System.Exception(ex.Message);
            }

        }

        private async Task<List<ValueResponse>> GetSizes(long PartTypeId)
        {
            var resp =await ampRepository.Query<PartTypeConfigurationSize>().Where(x => x.PartTypeId == PartTypeId  )
               .Join(ampRepository.Query<Size>(), pts => pts.SizeId, sz => sz.SizeId, (pts, sz) => new { sz.SizeId, sz.Name }).Select(y => new ValueResponse
               {
                   Id = y.SizeId.ToString(),
                  Value= y.Name

               }).ToListAsync();

            return resp;
        }

        private async Task<List<ValueResponse>> GetStyles(long PartTypeId)
        {
            var resp = await ampRepository.Query<PartTypeConfigurationStyle>().Where(x => x.PartTypeId == PartTypeId  )
               .Join(ampRepository.Query<Style>(), pts => pts.StyleId, sz => sz.StyleId, (pts, sz) => new { sz.StyleId, sz.Name }).Select(y => new ValueResponse
               {
                Id = y.StyleId.ToString(),
                  Value = y.Name
               }).ToListAsync();

            return resp;
        }

        private async Task<List<ValueResponse>> GetServices(long PartTypeId)
        {
            var resp = await ampRepository.Query<PartTypeConfigurationService>().Where(x => x.PartTypeId == PartTypeId)
               .Join(ampRepository.Query<Model.Service>(), pts => pts.ServiceId, sz => sz.ServiceId, (pts, sz) => new { sz.ServiceId, sz.Name }).Select(y => new ValueResponse
               {
                   Id = y.ServiceId.ToString(),
                   Value = y.Name
               }).ToListAsync();

            return resp;
        }

        private async Task<List<ValueResponse>> GetPressureRatings(long PartTypeId)
        {
            var resp = await ampRepository.Query<PartTypeConfigurationPressureRating>().Where(x => x.PartTypeId == PartTypeId)
               .Join(ampRepository.Query<PressureRating>(), pts => pts.PressureRatingId, sz => sz.PressureRatingId, (pts, sz) => new { sz.PressureRatingId, sz.Value }).Select(y => new ValueResponse
               {
                   Id = y.PressureRatingId.ToString(),
                   Value = y.Value.ToString()
               }).ToListAsync();

            return resp;
        }
        private async Task<List<ValueResponse>> GetDesignations(long PartTypeId)
        {
            var res = await ampRepository.Query<PartTypeConfigurationVariation>().Where(a => a.PartTypeId == PartTypeId)
                .Join(ampRepository.Query<Variation>(), pcv => pcv.VariationId, vc => vc.VariationId, (pcv, vc) => new { vc.VariationId, vc.Name })
                .Select(y => new ValueResponse
                {
                    Id = y.VariationId.ToString(),
                    Value = y.Name.ToString()

                }).ToListAsync();
            return res;
        }
      

        #endregion

        #region Task<Response> GetManufacturerNameById(int[] ids)
        public async Task<Response> GetManufacturerNameById(int[] ids)
        {
            var resp = await ampRepository.Query<Manufacturer>().Where(x => ids.Contains(x.ManufacturerId) &&x.IsActive==true).Select(m => new
            {
                m.Name,
                Id=m.ManufacturerId
            }).ToListAsync();

            return new Response() { Content = resp, status = true };
        }
        #endregion

        #region Task<Response> GetAssetDescriptionByPartNumbers
        public async Task<Response> GetAssetDescriptionByPartNumbers(string[]  PartNumbers)
        {           
            var part = await ampRepository.Query<PartReference>().Where(a => PartNumbers.Contains( a.PartNumber))
              .Join(ampRepository.Query<PartMaster>(), pr => pr.PartMasterId, pm => pm.PartMasterId, (pr, pm) => new { pr.PartNumber, pm.PartTypeId, pm.SizeId, pm.ServiceId, pm.StyleId, pm.PressureRatingId , pm.VariationId})
              .Join(ampRepository.Query<PartType>(), j => j.PartTypeId, pt => pt.PartTypeId, (j, pt) => new { j, pt }).Where(g=>g.pt.IsPumpPartType==true)
              .Join(ampRepository.Query<Size>(), r => r.j.SizeId, sz => sz.SizeId, (r, sz) => new { r, sz })
              .Join(ampRepository.Query<Style>(), t => t.r.j.StyleId, st => st.StyleId, (t, st) => new { t, st })
              .Join(ampRepository.Query<Model.Service>(), v => v.t.r.j.ServiceId, sr => sr.ServiceId, (v, sr) => new { v, sr })
              .Join(ampRepository.Query<PressureRating>(), i => i.v.t.r.j.PressureRatingId, p => p.PressureRatingId, (i, p) => new { i, p })
               .Join(ampRepository.Query<Variation>(), s => s.i.v.t.r.j.VariationId, d => d.VariationId, (s, d) => new { s, d })
              .Select(m => new
              {
                  m.s.i.v.t.r.j.PartNumber,
                  Description = $"{m.s.i.v.t.r.pt.Name} | {m.s.i.v.t.sz.Name} | {m.s.i.v.st.Name} | {m.s.i.sr.Name} | {m.s.p.Value} | {m.d.Name}",

              }).ToListAsync();

            Response response = new Response
            {
                status = true,
                Content = part
            };
            return response;

        }

        #endregion

        #region async Task<Response> GetPartNameByIds(int[] PartTypeIds)
        public async Task<Response> GetPartTypeByIds(int[] PartTypeIds)
        {
            var ressult = await ampRepository.Query<PartType>().Where(x => PartTypeIds.Contains(x.PartTypeId) && x.IsActive == true && x.IsPumpPartType == true).Select(m => new
            {
                m.Name,
                Id = m.PartTypeId
            }).ToListAsync();
            return new Response() { Content = ressult, status = true };
        }
        #endregion

        #region Task<Response> GetPartDetailsById
        public async Task<Response> GetPartDetailsByIds(string[] ids)
        {
            // Size, Style, Service, PressureRating and Designation          
            List<int> sizeIds = new List<int>();
            List<int> styleIds = new List<int>();
            List<int> serviceIds = new List<int>();
            List<int> pressureIds = new List<int>();
            List<int> variationIds = new List<int>();

            foreach (string id in ids)
            {
                if (!string.IsNullOrEmpty(id))
                {
                    string[] queryIds = id.Split("|");
                    if (!string.IsNullOrEmpty(queryIds[0]) && !sizeIds.Contains(Convert.ToInt32(queryIds[0].Trim())))
                        sizeIds.Add(Convert.ToInt32(queryIds[0].Trim()));
                    if (!string.IsNullOrEmpty(queryIds[1]) && !styleIds.Contains(Convert.ToInt32(queryIds[1].Trim())))
                        styleIds.Add(Convert.ToInt32(queryIds[1].Trim()));
                    if (!string.IsNullOrEmpty(queryIds[2]) && !serviceIds.Contains(Convert.ToInt32(queryIds[2].Trim())))
                        serviceIds.Add(Convert.ToInt32(queryIds[2].Trim()));
                    if (!string.IsNullOrEmpty(queryIds[3]) && !pressureIds.Contains(Convert.ToInt32(queryIds[3].Trim())))
                        pressureIds.Add(Convert.ToInt32(queryIds[3].Trim()));
                    if (!string.IsNullOrEmpty(queryIds[4]) && !variationIds.Contains(Convert.ToInt32(queryIds[4].Trim())))
                        variationIds.Add(Convert.ToInt32(queryIds[4].Trim()));
                }
            }

            // size
            var sizeResult = await ampRepository.Query<Size>().Where(x => sizeIds.Contains(x.SizeId) && x.IsActive == true).Select(m => new
            {
                m.SizeId,
                m.Name
            }).ToListAsync();

            // style
            var styleResult = await ampRepository.Query<Style>().Where(x => styleIds.Contains(x.StyleId) && x.IsActive == true).Select(m => new
            {
                m.StyleId,
                m.Name
            }).ToListAsync();

            // service
            var serviceResult = await ampRepository.Query<Model.Service>().Where(x => serviceIds.Contains(x.ServiceId) && x.IsActive == true).Select(m => new
            {
                m.ServiceId,
                m.Name
            }).ToListAsync();

            // pressure
            var pressureRatingResult = await ampRepository.Query<PressureRating>().Where(x => pressureIds.Contains(x.PressureRatingId) && x.IsActive == true).Select(m => new
            {
                m.PressureRatingId,
                m.Value
            }).ToListAsync();

            // designation
            var Designationresult = await ampRepository.Query<Variation>().Where(x => variationIds.Contains(x.VariationId) && x.IsActive == true).Select(m => new
            {
                m.VariationId,
                m.Name,
            }).ToListAsync();

            Dictionary<string, string> responseContent = new Dictionary<string, string>();
            foreach (string id in ids)
            {
                if (!string.IsNullOrEmpty(id))
                {
                    string[] queryIds = id.Split("|");
                    string value = $"{(!string.IsNullOrEmpty(queryIds[0]) ? sizeResult.Where(x => x.SizeId == Convert.ToInt32(queryIds[0])).FirstOrDefault()?.Name : "")} | " +
                            $"{(!string.IsNullOrEmpty(queryIds[1]) ? styleResult.Where(x => x.StyleId == Convert.ToInt32(queryIds[1])).FirstOrDefault()?.Name : "")} | " +
                            $"{(!string.IsNullOrEmpty(queryIds[2]) ? serviceResult.Where(x => x.ServiceId == Convert.ToInt32(queryIds[2])).FirstOrDefault()?.Name : "")} | " +
                      $"{(!string.IsNullOrEmpty(queryIds[3]) ? pressureRatingResult.Where(x => x.PressureRatingId == Convert.ToInt32(queryIds[3])).FirstOrDefault()?.Value : 0)} | " +
                      $"{(!string.IsNullOrEmpty(queryIds[4]) ? Designationresult.Where(x => x.VariationId == Convert.ToInt32(queryIds[4])).FirstOrDefault()?.Name : "")}";
                    if (!responseContent.ContainsKey(id))
                        responseContent.Add(id, value);
                }
            }
            return new Response() { Content = responseContent, status = true };
        }
        #endregion

        #region async Task<Response> GetComponentRuleDetailsForClearanceOrTorqueAsync(string partNumber, int customerId, int manufacturerId)
        public async Task<Response> GetComponentRuleDetailsForClearanceOrTorqueAsync(string partNumber, int customerId, int manufacturerId)
        {
            var result = await partRepository.GetComponentRuleDetailsForClearanceOrTorqueAsync(partNumber, customerId, manufacturerId);
            PartComponentRuleResponse partComponent = new PartComponentRuleResponse();

            if (result.Count > 0)
            {
                partComponent.SpecBook = result[0].InspectionStandardName;
                partComponent.RuleName = result[0].WallThicknessRule;
                partComponent.RuleDetails = new List<PartComponentRuleDetail>();
                int i = 1;
                foreach (ProcPartComponentRuleDetail e in result)
                    partComponent.RuleDetails.Add(new PartComponentRuleDetail() { BearingNumber = i++, MinimumValue = e.MinimumThickness, MaximumValue = e.MaximumThickness });

                return new Response() { Content = partComponent, status = true, Message = Messages.GetSuccess };
            }
            
            return new Response() { status = false, Message = Messages.NoData };
        }
        #endregion  
    }

}
