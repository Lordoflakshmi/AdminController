﻿using AMP.Administration.Service.DTOs.Responses;
using AMP.Administration.Service.DTO.Response;
using AMP.Administration.Service.Model;
using AMP.Administration.Service.RepositoryContract;
using AMP.Administration.Service.ServiceContract;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AMP.Administration.Service.ServiceImplementation
{
    public class UserService : IUser
    {
        private readonly IAMPRepository ampRepository;

        public UserService(IAMPRepository _ampRepository)
        {
            this.ampRepository = _ampRepository;
        }

        #region async Task<UserResponse> GetUserDetailsAsync(Guid claim)
        public async Task<UserResponse> GetUserDetailsAsync(Guid claim)
        {
            var userDetails = new UserResponse();
            try
            {
                var features = new List<string>();
                userDetails = await ampRepository.Query<UserSession>()
                    .Where(c => c.Id == claim)
                    .Join(ampRepository.Query<User>(), us => us.UserId, u => u.UserId, (us, u) => new UserResponse()
                    {
                        UserId = u.UserId,
                        UserName = u.LoginUserName,
                        FirstName = u.FirstName,
                        LastName = u.LastName,
                        UserType = u.IsCustomer ? "Customer" : "Internal"
                    })
                    .Select(s => s)
                    .SingleOrDefaultAsync();

                if (userDetails != null)
                {
                    features = await ampRepository.Query<User>()
                        .Where(c => c.UserId == userDetails.UserId && c.Status == 1 && !c.IsDelete)
                        .Join(ampRepository.Query<UserSecurityGroup>(), u => u.UserId, usg => usg.UserId, (u, usg) => new { u, usg })
                        .Join(ampRepository.Query<SecurityGroup>(), j => j.usg.SecurityGroupId, usg => usg.SecurityGroupId, (u, usg) => new { u, usg })
                        .Join(ampRepository.Query<SecurityGroupFeature>().Where(a => a.IsReadOnly == true), e => e.usg.SecurityGroupId, sg => sg.SecurityGroupId, (e, sg) => new { e, sg })
                        .Join(ampRepository.Query<Feature>(), r => r.sg.FeatureId, f => f.FeatureId, (r, f) => new { r, f })
                        .Join(ampRepository.Query<FeatureModule>(), m => m.f.ParentFeatureId, f => f.ModuleId, (m, f) => new { m, f }).Where(a => a.f.ModuleName.Equals("Pump - System Administration") || a.f.ModuleName.Equals("Pump - Work order") || a.f.ModuleName.Equals("Pump - Inventory") || a.f.ModuleName.Equals("Pump - Inspection") || a.f.ModuleName.Equals("Pump - Pickup") || a.f.ModuleName.Equals("Pump - Reports") || a.f.ModuleName.Equals("Pump - Dashboard Charts"))
                        .Select(s => s.m.f.ShortName)
                        .ToListAsync();
                }

                userDetails.Features = features;
            }
            catch (Exception ex)
            {
                var errorMsg = ex.Message;
            }

            return userDetails;
        }
        #endregion

        #region async Task<List<Response>> GetUserNamesAsync()
        public async Task<Response> GetUserNamesAsync(long[] UserIds)
        {
            var resp = await ampRepository.Query<User>().Where(x => UserIds.Contains(x.UserId)).Select(m => new
            {
                Id = m.UserId,
                Name = m.LastName + " " + m.FirstName,
            }).ToListAsync();

            return new Response() { Content = resp, status = true };
        }
        #endregion

        #region async Task<List<Response>> GetUserNamesAsync()
        public async Task<Response> GetCustomerUserAsync(long orgGrpId)
        {
            var resp = await ampRepository.Query<User>().Where(x => x.OrganizationalGroupId == orgGrpId)
                            .Select(m => new
                            {
                               UserId = m.UserId,
                            }).ToListAsync();

            return new Response() { Content = resp, status = true };

        }
        #endregion


    }
}
