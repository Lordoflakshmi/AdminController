﻿using AMP.Administration.Service.DTO.Response;
using AMP.Administration.Service.Model;
using AMP.Administration.Service.RepositoryContract;
using AMP.Administration.Service.ServiceContract;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AMP.Administration.Service.ServiceImplementation
{
    public class ManufacturerService : IManufacturer
    {
        private readonly IAMPRepository ampRepository;
        public ManufacturerService(IAMPRepository _ampRepository)
        {
            this.ampRepository = _ampRepository;
        }

        #region async Task<List<ValueResponse>> GetManufacturer()
        public async Task<Response> GetManufacturer()
        {
            var result = await ampRepository.Query<Manufacturer>()
                    .Where(a => a.IsActive == true)
                    .Select(a => new ValueResponse { Id = a.ManufacturerId.ToString(), Value = a.Name })
                    .ToListAsync();
            return (new Response() { Content = result });
        }
        #endregion

        #region async Task<Response> GetManufacturerNames(long[] ManufacturerIds)
        public async Task<Response> GetManufacturerNames(long[] ManufacturerIds)
        {
            var response = await ampRepository.Query<Manufacturer>().Where(x => ManufacturerIds.Contains(x.ManufacturerId)).Select(m => new
            {
                Id = m.ManufacturerId,
                Name = m.Name
            }).ToListAsync();

            return new Response() { Content = response, status = true };
        }
        #endregion
    }
}
