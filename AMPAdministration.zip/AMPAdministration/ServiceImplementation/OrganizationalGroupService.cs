﻿using AMP.Administration.Service.DTO.Request;
using AMP.Administration.Service.DTO.Response;
using AMP.Administration.Service.Helpers;
using AMP.Administration.Service.Model;
using AMP.Administration.Service.RepositoryContract;
using AMP.Administration.Service.ServiceContract;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Internal;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AMP.Administration.Service.ServiceImplementation
{
    public class OrganizationalGroupService : IOrganizationalGroup
    {
        private readonly IAMPRepository ampRepository;
        public OrganizationalGroupService(IAMPRepository _ampRepository)
        {
            this.ampRepository = _ampRepository;
        }

        #region async Task<List<ValueResponse>> GetOrganizationGroups(int levelid,int Id,string requestedById)
        public async Task<Response> GetOrganizationGroups(int levelid, int Id, string requestedById)
        {
            var result = await ampRepository.Query<User>().Where(a => a.UserId == Convert.ToInt64(requestedById))
                .Select(a => new
                {
                    a.OrganizationalGroupId

                }).FirstOrDefaultAsync();

            Response response = new Response();

            var results = await GetOriganizationalGroup(levelid, Id);
            response.Content = results;

            return response;
        }

        private async Task<List<ValueResponse>> GetOriganizationalGroup(int levelid, int Id)
        {
            var result = await ampRepository.Query<OrganizationalGroup>()
                   .Where(a => a.IsActive == true && a.IsDelete == false && a.ParentGroupId == Id && a.OrganizationalGroupLevelId == levelid)
                   .Select(a => new ValueResponse
                   {
                       Id = a.OrganizationalGroupId.ToString(),
                       Value = a.Name.ToString(),
                   })
                   .ToListAsync();



            return result;
        }


        #endregion

        #region Task<Response> GetOrganizationalGroupHierarchy
        public async Task<Response> GetOrganizationalGroupHierarchy(string requestedById)
        {

            var userResp = await ampRepository.Query<Model.User>().Where(a => a.UserId == Convert.ToInt64(requestedById))
                .Select(a => new
                {
                    a.OrganizationalGroupId
                }).FirstOrDefaultAsync();

            Response response = new Response();
            if (userResp != null && Convert.ToInt64(userResp.OrganizationalGroupId) != 0)
            {
                var orgResp = await GetOrganizationDetails(Convert.ToInt64(userResp.OrganizationalGroupId));
                response.Content = orgResp;
            }


            return response;
        }



        private async Task<Response> GetOrganizationDetails(long OrganizationalGroupId)
        {

            var resp = await ampRepository.Query<OrganizationalGroup>().Where(a => a.OrganizationalGroupId == OrganizationalGroupId)
                                                .Select(a => new
                                                {
                                                    Id = a.OrganizationalGroupId,
                                                    LevelId = a.OrganizationalGroupLevelId,
                                                    ParentId = a.ParentGroupId

                                                }).FirstOrDefaultAsync();
            Response response = new Response();
            int LevelId = (int)resp.LevelId;


            if (LevelId == 7)
            {

                var x = await ampRepository.Query<OrganizationalGroup>().Where(a => a.OrganizationalGroupId == OrganizationalGroupId)
                     .Join(ampRepository.Query<OrganizationalGroup>(), x => x.ParentGroupId, y => y.OrganizationalGroupId, (x, y) => new { group_unit_id = x.OrganizationalGroupId, group_unit_name = x.Name, unit_LevelId = x.OrganizationalGroupLevelId, district_id = y.OrganizationalGroupId, district_name = y.Name, district_LevelId = y.OrganizationalGroupLevelId, district_ParentGroupId = y.ParentGroupId })

                         .Join(ampRepository.Query<OrganizationalGroup>(), a => a.district_ParentGroupId, b => b.OrganizationalGroupId, (a, b) => new { a, region_id = b.OrganizationalGroupId, region_name = b.Name, region_LevelId = b.OrganizationalGroupLevelId, region_ParentGroupId = b.ParentGroupId })

                         .Join(ampRepository.Query<OrganizationalGroup>(), c => c.region_ParentGroupId, d => d.OrganizationalGroupId, (c, d) => new { c, area_id = d.OrganizationalGroupId, area_name = d.Name, area_LevelId = d.OrganizationalGroupLevelId, area_ParentGroupId = d.ParentGroupId })

                         .Join(ampRepository.Query<OrganizationalGroup>(), e => e.area_ParentGroupId, f => f.OrganizationalGroupId, (e, f) => new { e, customer_id = f.OrganizationalGroupId, customer_name = f.Name, customer_LevelId = f.OrganizationalGroupLevelId, customer_ParentGroupId = f.ParentGroupId })

                         .Join(ampRepository.Query<OrganizationalGroup>(), g => g.customer_ParentGroupId, h => h.OrganizationalGroupId, (g, h) => new { g, organization_id = h.OrganizationalGroupId, organization_name = h.Name, organization_LevelId = h.OrganizationalGroupLevelId, organization_ParentGroupId = h.ParentGroupId })
                         .Select(z => new
                         {
                             z.organization_id,
                             z.organization_name,
                             z.organization_LevelId,
                             z.g.customer_id,
                             z.g.customer_name,
                             z.g.customer_LevelId,
                             z.g.e.area_id,
                             z.g.e.area_name,
                             z.g.e.area_LevelId,
                             z.g.e.c.region_id,
                             z.g.e.c.region_name,
                             z.g.e.c.region_LevelId,
                             z.g.e.c.a.district_id,
                             z.g.e.c.a.district_name,
                             z.g.e.c.a.district_LevelId,
                             z.g.e.c.a.group_unit_id,
                             z.g.e.c.a.group_unit_name,
                             z.g.e.c.a.unit_LevelId
                         })
                         .FirstOrDefaultAsync();
                response.Content = x;
            }
            else if (LevelId == 6)
            {
                var x = await ampRepository.Query<OrganizationalGroup>().Where(a => a.OrganizationalGroupId == OrganizationalGroupId)

                         .Join(ampRepository.Query<OrganizationalGroup>(), a => a.ParentGroupId, b => b.OrganizationalGroupId, (a, b) => new { district_id = a.OrganizationalGroupId, district_name = a.Name, district_LevelId = a.OrganizationalGroupLevelId, region_id = b.OrganizationalGroupId, region_name = b.Name, region_LevelId = b.OrganizationalGroupLevelId, region_ParentGroupId = b.ParentGroupId })

                         .Join(ampRepository.Query<OrganizationalGroup>(), c => c.region_ParentGroupId, d => d.OrganizationalGroupId, (c, d) => new { c, area_id = d.OrganizationalGroupId, area_name = d.Name, area_LevelId = d.OrganizationalGroupLevelId, area_ParentGroupId = d.ParentGroupId })

                         //.Join(ampRepository.Query<OrganizationalGroup>(), x => x.area_ParentGroupId, t => t.OrganizationalGroupId, (k, t) => new { k, devion_id = t.OrganizationalGroupId, devion_name = t.Name, division_LevelId = t.OrganizationalGroupLevelId, division_ParentGroupId = t.ParentGroupId })

                         .Join(ampRepository.Query<OrganizationalGroup>(), e => e.area_ParentGroupId, f => f.OrganizationalGroupId, (e, f) => new { e, customer_id = f.OrganizationalGroupId, customer_name = f.Name, Customer_LevelId = f.OrganizationalGroupLevelId, customer_ParentGroupId = f.ParentGroupId })

                         .Join(ampRepository.Query<OrganizationalGroup>(), g => g.customer_ParentGroupId, h => h.OrganizationalGroupId, (g, h) => new { g, organization_id = h.OrganizationalGroupId, organization_name = h.Name, organization_LevelId = h.OrganizationalGroupLevelId, organization_ParentGroupId = h.ParentGroupId })
                         .Select(z => new
                         {
                             z.organization_id,
                             z.organization_name,
                             z.organization_LevelId,
                             z.g.customer_id,
                             z.g.customer_name,
                             z.g.Customer_LevelId,
                             z.g.e.area_id,
                             z.g.e.area_name,
                             z.g.e.area_LevelId,
                             z.g.e.c.region_id,
                             z.g.e.c.region_name,
                             z.g.e.c.region_LevelId,
                             z.g.e.c.district_id,
                             z.g.e.c.district_name,
                             z.g.e.c.district_LevelId
                         })
                         .FirstOrDefaultAsync();
                response.Content = x;
            }
            else if (LevelId == 5)
            {
                var x = await ampRepository.Query<OrganizationalGroup>().Where(a => a.OrganizationalGroupId == OrganizationalGroupId)

                         .Join(ampRepository.Query<OrganizationalGroup>(), a => a.ParentGroupId, b => b.OrganizationalGroupId, (a, d) => new { region_id = a.OrganizationalGroupId, region_name = a.Name, region_LevelId = a.OrganizationalGroupLevelId, area_id = d.OrganizationalGroupId, area_name = d.Name, area_LevelId = d.ParentGroupId, area_ParentGroupId = d.ParentGroupId })

                          //.Join(ampRepository.Query<OrganizationalGroup>(), x => x.area_ParentGroupId, t => t.OrganizationalGroupId, (k, t) => new
                          //{
                          //    k,
                          //    devion_id = t.OrganizationalGroupId,
                          //    devion_name = t.Name,
                          //    division_LevelId = t.OrganizationalGroupLevelId,
                          //    division_ParentGroupId = t.ParentGroupId
                          //})

                         .Join(ampRepository.Query<OrganizationalGroup>(), c => c.area_ParentGroupId, d => d.OrganizationalGroupId, (c, f) => new { c, customer_id = f.OrganizationalGroupId, customer_name = f.Name, Customer_LevelId = f.OrganizationalGroupLevelId, customer_ParentGroupId = f.ParentGroupId })

                         .Join(ampRepository.Query<OrganizationalGroup>(), e => e.customer_ParentGroupId, f => f.OrganizationalGroupId, (e, h) => new { e, organization_id = h.OrganizationalGroupId, organization_name = h.Name, orgnization_LevelId = h.OrganizationalGroupLevelId, organization_ParentGroupId = h.ParentGroupId })
                         .Select(z => new
                         {
                             z.organization_id,
                             z.organization_name,
                             z.orgnization_LevelId,
                             z.e.customer_id,
                             z.e.customer_name,
                             z.e.Customer_LevelId,
                             z.e.c.area_id,
                             z.e.c.area_name,
                             z.e.c.area_LevelId,
                             z.e.c.region_id,
                             z.e.c.region_name,
                             z.e.c.region_LevelId
                         })
                         .FirstOrDefaultAsync();
                response.Content = x;
            }
            else if (LevelId == 4)
            {
                var x = await ampRepository.Query<OrganizationalGroup>().Where(a => a.OrganizationalGroupId == OrganizationalGroupId)

                         .Join(ampRepository.Query<OrganizationalGroup>(), a => a.ParentGroupId, b => b.OrganizationalGroupId, (a, d) => new
                         {
                             area_id = a.OrganizationalGroupId,
                             area_name = a.Name,
                             area_LevelId = a.OrganizationalGroupLevelId,
                             customer_id = a.OrganizationalGroupId,
                             customer_name = a.Name,
                             Customer_LevelId = a.OrganizationalGroupLevelId,
                             Customer_ParentGroupId = d.ParentGroupId

                             //divion_id = d.OrganizationalGroupId,
                             //divion_name = d.Name,
                             //division_LevelId = d.OrganizationalGroupLevelId,
                             //division_ParentGroupId = d.ParentGroupId
                         })
                         //.Join(ampRepository.Query<OrganizationalGroup>(), c => c.Customer_ParentGroupId, d => d.OrganizationalGroupId, (c, f) => new { c, customer_id = f.OrganizationalGroupId, customer_name = f.Name, Customer_LevelId = f.OrganizationalGroupLevelId, customer_ParentGroupId = f.ParentGroupId })

                         .Join(ampRepository.Query<OrganizationalGroup>(), e => e.Customer_ParentGroupId, f => f.OrganizationalGroupId, (e, h) => new { e, organization_id = h.OrganizationalGroupId, organization_name = h.Name, organization_LevelId = h.OrganizationalGroupLevelId, organization_ParentGroupId = h.ParentGroupId })
                         .Select(z => new
                         {
                             z.organization_id,
                             z.organization_name,
                             z.organization_LevelId,
                             z.e.customer_id,
                             z.e.customer_name,
                             z.e.Customer_LevelId,
                             z.e.area_id,
                             z.e.area_name,
                             z.e.area_LevelId

                         })
                         .FirstOrDefaultAsync();
                response.Content = x;
            }
            else if (LevelId == 2)
            {
                var x = await ampRepository.Query<OrganizationalGroup>().Where(a => a.OrganizationalGroupId == OrganizationalGroupId)
                         .Join(ampRepository.Query<OrganizationalGroup>(), a => a.ParentGroupId, b => b.OrganizationalGroupId, (a, d) => new
                         {
                             customer_id = a.OrganizationalGroupId,
                             customer_name = a.Name,
                             Customer_LevelId = a.OrganizationalGroupLevelId,
                             organization_id = d.OrganizationalGroupId,
                             organization_name = d.Name,
                             organization_LevelId = d.OrganizationalGroupLevelId,
                             organization_ParentGroupId = d.ParentGroupId
                         })
                      .Select(z => new
                      {
                          z.organization_id,
                          z.organization_name,
                          z.organization_LevelId,
                          z.customer_id,
                          z.customer_name,
                          z.Customer_LevelId
                      })
                         .FirstOrDefaultAsync();
                response.Content = x;
            }
            else if (LevelId == 1)
            {
                var x = await ampRepository.Query<OrganizationalGroup>().Where(a => a.OrganizationalGroupId == OrganizationalGroupId)
                .Select(z => new
                {
                    z.Name,
                    z.OrganizationalGroupId,
                    z.OrganizationalGroupLevelId,
                })
                         .FirstOrDefaultAsync();
                response.Content = x;
            }

            return response;


        }
        #endregion

        #region public async Task<Response> GetOrganizationalGroupHierarchyNameByIdAsync(long id)
        public async Task<Response> GetOrganizationalGroupHierarchyNameByIdAsync(long id)
        {
            var response = new Response();
            var orgGroupHeirarchy = new OrganizationalGroupHeirarchyNameResponse();

            var organizationalHierarchy = await ampRepository.Query<OrganizationHierarchy>()
                .SingleOrDefaultAsync(e => e.OrgGroupId == id);

            if (organizationalHierarchy != null)
            {
                orgGroupHeirarchy.OrganizationName = await GetOrganizationalGroupName(organizationalHierarchy.OrganizationId);
                orgGroupHeirarchy.CustomerName = await GetOrganizationalGroupName(organizationalHierarchy.CompanyId);
                orgGroupHeirarchy.AreaName = await GetOrganizationalGroupName(organizationalHierarchy.AreaId);
                orgGroupHeirarchy.RegionName = await GetOrganizationalGroupName(organizationalHierarchy.RegionId);
                orgGroupHeirarchy.DistrictName = await GetOrganizationalGroupName(organizationalHierarchy.DistrictId);
                orgGroupHeirarchy.GroupName = await GetOrganizationalGroupName(organizationalHierarchy.GroupId);

                response.Content = orgGroupHeirarchy;
                response.Message = AdministrationMessages.GetSuccess;
                response.status = true;
            }

            return response;
        }

        private async Task<string> GetOrganizationalGroupName(long? id)
        {
            var organizationalGroup = new OrganizationalGroup();
            if (id != null)
            {
                organizationalGroup = await ampRepository.Query<OrganizationalGroup>()
                    .SingleOrDefaultAsync(e => e.OrganizationalGroupId == id);
            }
            return organizationalGroup.Name;
        }
        #endregion

        #region public async Task<Response> GetOrganizationalGroupHierarchyNameByIdAsync(long[] id)
        public async Task<Response> GetOrganizationalGroupHierarchyNameByIdAsync(string[] orgGroupId)
        {
            long[] OrgGroupId = Array.ConvertAll(orgGroupId, long.Parse);
            var response = new Response();
            List<OrganizationalGroupHeirarchyNameWithIdResponse> orgGroupHeirarchy = new List<OrganizationalGroupHeirarchyNameWithIdResponse>();               
            var organizationalHierarchy = await ampRepository.Query<OrganizationHierarchy>()
                .Where(e => OrgGroupId.Contains(e.OrgGroupId)).ToArrayAsync();
            int i = 0;
            if (organizationalHierarchy != null)
            {
                foreach (var item in organizationalHierarchy)
                {
                    orgGroupHeirarchy.Add(new OrganizationalGroupHeirarchyNameWithIdResponse()
                    {
                        orgGroupId= OrgGroupId[i],
                        OrganizationId = item.OrganizationId,
                        OrganizationName = await GetOrganizationalGroupName(item.OrganizationId),
                        CompanyId = item.CompanyId,
                        CompanyName = await GetOrganizationalGroupName(item.CompanyId),
                        AreaId = item.AreaId,
                        AreaName = await GetOrganizationalGroupName(item.AreaId),
                        RegionId = item.RegionId,
                        RegionName = await GetOrganizationalGroupName(item.RegionId),
                        DistrictId = item.DistrictId,
                        DistrictName = await GetOrganizationalGroupName(item.DistrictId),
                        GroupId = item.GroupId,
                        GroupName = await GetOrganizationalGroupName(item.GroupId)
                    });
                    i++;                
                }
                response.Content = orgGroupHeirarchy;
                response.Message = AdministrationMessages.GetSuccess;
                response.status = true;
            }

            return response;
        }


        #endregion

        #region async Task<List<Response>> GetOrganizationsName()
        public async Task<Response> GetOrganizationsName(long[] OrganizationsIds)
        {
            var resp = await ampRepository.Query<OrganizationalGroup>().Where(x => OrganizationsIds.Contains(x.OrganizationalGroupId)).Select(m => new
            {
                Id = m.OrganizationalGroupId,
                Name = m.Name
            }).ToListAsync();

            return new Response() { Content = resp, status = true };
        }
        #endregion

        #region async Task<List<Response>> GetOrganizationsName()
        public async Task<Response> GetOrganizationParentGroup(long[] OrganizationsIds)
        {
            var response = new Response();
            var result = await ampRepository.Query<OrganizationalGroup>().Where(x => OrganizationsIds.Contains(x.OrganizationalGroupId)).Select(t => new
            {
                Id = t.OrganizationalGroupId,
                LevelId = t.OrganizationalGroupLevelId

            }).FirstOrDefaultAsync();
            int LevelId = (int)result.LevelId;
            if (LevelId == 1)
            {

                var resp = await ampRepository.Query<OrganizationalGroup>().Where(x => OrganizationsIds.Contains(x.OrganizationalGroupId)).Join(ampRepository.Query<OrganizationalGroup>(), x => x.OrganizationalGroupId, c => c.ParentGroupId, (x, c) => new { x, c }).
                    Select(m => new
                    {
                        Id = m.c.OrganizationalGroupId,
                        Name = m.c.OrganizationalGroupLevelId
                    }).ToListAsync();

                return new Response() { Content = resp, status = true };
            }
            else if (LevelId == 2)
            {
                var resp = await ampRepository.Query<OrganizationalGroup>().Where(x => OrganizationsIds.Contains(x.OrganizationalGroupId)).Join(ampRepository.Query<OrganizationHierarchy>(), x => x.OrganizationalGroupId, c => c.CompanyId, (x, c) => new { x, c }).Select(m => new
                {
                    Id = m.c.OrgGroupId,
                    Name = m.x.OrganizationalGroupLevelId

                }).ToListAsync();
                return new Response() { Content = resp, status = true };

            }
            else if (LevelId == 4)
            {
                var resp = await ampRepository.Query<OrganizationalGroup>().Where(x => OrganizationsIds.Contains(x.OrganizationalGroupId)).Join(ampRepository.Query<OrganizationHierarchy>(), x => x.OrganizationalGroupId, c => c.AreaId, (x, c) => new { x, c }).Select(m => new
                {
                    Id = m.c.OrgGroupId,
                    Name = m.x.OrganizationalGroupLevelId

                }).ToListAsync();
                return new Response() { Content = resp, status = true };
            }
            else if (LevelId == 5)
            {
                var resp = await ampRepository.Query<OrganizationalGroup>().Where(x => OrganizationsIds.Contains(x.OrganizationalGroupId)).Join(ampRepository.Query<OrganizationHierarchy>(), x => x.OrganizationalGroupId, c => c.RegionId, (x, c) => new { x, c }).Select(m => new
                {
                    Id = m.c.OrgGroupId,
                    Name = m.x.OrganizationalGroupLevelId


                }).ToListAsync();
                return new Response() { Content = resp, status = true };

            }
            else if (LevelId == 6)
            {
                var resp = await ampRepository.Query<OrganizationalGroup>().Where(x => OrganizationsIds.Contains(x.OrganizationalGroupId)).Join(ampRepository.Query<OrganizationHierarchy>(), x => x.OrganizationalGroupId, c => c.DistrictId, (x, c) => new { x, c }).Select(m => new
                {
                    Id = m.c.OrgGroupId,
                    Name = m.x.OrganizationalGroupLevelId


                }).ToListAsync();
                return new Response() { Content = resp, status = true };

            }
            else if (LevelId == 7)
            {
                var resp = await ampRepository.Query<OrganizationalGroup>().Where(x => OrganizationsIds.Contains(x.OrganizationalGroupId)).Join(ampRepository.Query<OrganizationHierarchy>(), x => x.OrganizationalGroupId, c => c.GroupId, (x, c) => new { x, c }).Select(m => new
                {
                    Id = m.c.OrgGroupId,
                    Name = m.x.OrganizationalGroupLevelId


                }).ToListAsync();
                return new Response() { Content = resp, status = true };

            }
            return response;

        }
        #endregion


    }
}
