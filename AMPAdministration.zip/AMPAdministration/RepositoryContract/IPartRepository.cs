﻿using AMP.Administration.Service.DTO.Response;
using AMP.Administration.Service.Model;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Weir.AMP.Core.DataAccess.Interface;

namespace AMP.Administration.Service.RepositoryContract
{
    public interface IPartRepository
    {
        Task<List<ProcPartComponentRuleDetail>> GetComponentRuleDetailsForClearanceOrTorqueAsync(string partNumber, int customerId, int manufacturerId);
    }
}
