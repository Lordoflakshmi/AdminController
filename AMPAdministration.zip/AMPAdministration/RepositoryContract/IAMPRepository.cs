﻿using System;
using System.Collections.Generic;
using System.Text;
using Weir.AMP.Core.DataAccess.Interface;

namespace AMP.Administration.Service.RepositoryContract
{
    public interface IAMPRepository : IRepositoryBase
    {

    }
}
