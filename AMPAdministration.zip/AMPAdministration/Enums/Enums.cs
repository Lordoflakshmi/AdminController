﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AMP.Administration.Service.Enums
{
    public enum LocationHierarchyLevel
    {
        Region = 4,
        Location = 5
    }
}
