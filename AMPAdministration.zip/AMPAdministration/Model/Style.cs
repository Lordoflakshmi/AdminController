﻿using System;
using System.Collections.Generic;

namespace AMP.Administration.Service.Model
{
    public partial class Style
    {
        public int StyleId { get; set; }
        public string Name { get; set; }
        public bool? IsActive { get; set; }
        public long? CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
    }
}
