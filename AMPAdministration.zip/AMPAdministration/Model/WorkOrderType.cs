﻿using System;
using System.Collections.Generic;

namespace AMP.Administration.Service.Model
{
    public partial class WorkOrderType
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public bool IsOrganizationStructureRequired { get; set; }
        public bool IsActive { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public bool? IsAlternateCustomerRequired { get; set; }
        public bool? IsAssetLevelInspectionDurationRequired { get; set; }
        public bool IsPumpWorkOrderType { get; set; }
    }
}
