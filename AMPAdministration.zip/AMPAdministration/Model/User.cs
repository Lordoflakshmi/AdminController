﻿using System;
using System.Collections.Generic;

namespace AMP.Administration.Service.Model
{
    public partial class User
    {
        public long UserId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public short Status { get; set; }
        public string LoginUserName { get; set; }
        public string LoginPassword { get; set; }
        public string EmailAddress { get; set; }
        public long? OrganizationalGroupId { get; set; }
        public long? CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public long? UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public bool IsResetPwd { get; set; }
        public bool IsCustomer { get; set; }
        public bool IsDelete { get; set; }
        public string LocationId { get; set; }
        public long? DocumentId { get; set; }
        public int? LanguageId { get; set; }
        public short? Unit { get; set; }
    }
}
