﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace AMP.Administration.Service.Model
{
    public partial class PartTypeConfigurationService
    {
        [Key]
        public int ConfigurationServiceId { get; set; }
        public int? PartTypeId { get; set; }
        public int? ServiceId { get; set; }
    }
}
