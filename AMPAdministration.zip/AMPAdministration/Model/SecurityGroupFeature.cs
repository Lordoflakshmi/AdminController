﻿using System;
using System.Collections.Generic;

namespace AMP.Administration.Service.Model
{
    public partial class SecurityGroupFeature
    {
        public long SecurityGroupFeatureId { get; set; }
        public int SecurityGroupId { get; set; }
        public int FeatureId { get; set; }
        public bool IsReadOnly { get; set; }
        public bool IsAdd { get; set; }
        public bool IsEdit { get; set; }
        public bool IsDelete { get; set; }
        public long CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public long? UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }

        public virtual Feature Feature { get; set; }
        public virtual SecurityGroup SecurityGroup { get; set; }
    }
}
