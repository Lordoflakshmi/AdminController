﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AMP.Administration.Service.Model
{
   public class Variation
    {
        public Variation()
        {
            PartTypeConfigurationVariation = new HashSet<PartTypeConfigurationVariation>();
        }

        public int VariationId { get; set; }
        public string Name { get; set; }
        public bool? IsActive { get; set; }
        public long? CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public long? UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }

        public virtual ICollection<PartTypeConfigurationVariation> PartTypeConfigurationVariation { get; set; }
    }
}
