﻿using System;
using System.Collections.Generic;

namespace AMP.Administration.Service.Model
{
    public partial class UserSession
    {
        public Guid Id { get; set; }
        public long UserId { get; set; }
    }
}
