﻿using System;
using System.Collections.Generic;

namespace AMP.Administration.Service.Model
{
    public partial class GaugeType
    {
        public GaugeType()
        {
            Gauge = new HashSet<Gauge>();
        }

        public int GaugeTypeId { get; set; }
        public string GaugeTypeName { get; set; }
        public string GaugeTypeLegacyName { get; set; }
        public decimal? GaugeTypeCalibrationInterval { get; set; }
        public short GaugeTypeSort { get; set; }

        public virtual ICollection<Gauge> Gauge { get; set; }
    }
}
