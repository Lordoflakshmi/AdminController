﻿using System;
using System.Collections.Generic;

namespace AMP.Administration.Service.Model
{
    public partial class FeatureModule
    {
        public int ModuleId { get; set; }
        public string ModuleName { get; set; }
    }
}
