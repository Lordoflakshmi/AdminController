﻿using System;
using System.Collections.Generic;

namespace AMP.Administration.Service.Model
{
    public partial class Location
    {
        public long LocationId { get; set; }
        public string LocationName { get; set; }
        public int? CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public int? UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public int? LocationHierarchyId { get; set; }
        public int? WorkOrderTypeId { get; set; }
        public bool? IsNotificationApplicable { get; set; }
    }
}
