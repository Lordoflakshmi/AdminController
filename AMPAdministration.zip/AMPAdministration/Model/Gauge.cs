﻿using System;
using System.Collections.Generic;

namespace AMP.Administration.Service.Model
{
    public partial class Gauge
    {
        public int Id { get; set; }
        public string GaugeId { get; set; }
        public int GaugeTypeId { get; set; }
        public string Gtype { get; set; }
        public string GaugeDesc { get; set; }
        public DateTime? Gcdate { get; set; }
        public decimal? Life { get; set; }
        public bool IsActive { get; set; }
        public decimal? CalibrationValue { get; set; }
        public decimal? CalibrationValue2 { get; set; }
        public int? NoGoGaugeKitTypeId { get; set; }
        public long? LocationId { get; set; }
        public int? CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public int? UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public decimal? CalibrationValue1 { get; set; }

        public virtual GaugeType GaugeType { get; set; }
    }
}
