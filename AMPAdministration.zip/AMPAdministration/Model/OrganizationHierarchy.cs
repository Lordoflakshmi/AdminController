﻿using System;
using System.Collections.Generic;

namespace AMP.Administration.Service.Model
{
    public partial class OrganizationHierarchy
    {
        public long OrgGroupId { get; set; }
        public long? OrganizationId { get; set; }
        public long? CompanyId { get; set; }
        public long? DivisionId { get; set; }
        public long? AreaId { get; set; }
        public long? RegionId { get; set; }
        public long? DistrictId { get; set; }
        public long? GroupId { get; set; }
        public long? SiteId { get; set; }
    }
}
