﻿using System;
using System.Collections.Generic;

namespace AMP.Administration.Service.Model
{
    public partial class OrganizationalGroup
    {
        public long OrganizationalGroupId { get; set; }
        public string Name { get; set; }
        public long? ParentGroupId { get; set; }
        public long CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public long? UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public bool? IsActive { get; set; }
        public bool IsDelete { get; set; }
        public int? OrganizationalGroupLevelId { get; set; }
    }
}