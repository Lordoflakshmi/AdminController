﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace AMP.Administration.Service.Model
{
   public class PartTypeConfigurationVariation
    {
        [Key]
        public int ConfigurationVariationId { get; set; }
        public int? PartTypeId { get; set; }
        public int? VariationId { get; set; }

        public virtual Variation Variation { get; set; }
    }
}
