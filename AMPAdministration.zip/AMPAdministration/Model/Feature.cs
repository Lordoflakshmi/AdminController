﻿using System;
using System.Collections.Generic;

namespace AMP.Administration.Service.Model
{
    public partial class Feature
    {
        public Feature()
        {
            SecurityGroupFeature = new HashSet<SecurityGroupFeature>();
        }

        public int FeatureId { get; set; }
        public string Name { get; set; }
        public int? ParentFeatureId { get; set; }
        public string ShortName { get; set; }
        public virtual ICollection<SecurityGroupFeature> SecurityGroupFeature { get; set; }
    }
}
