﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AMP.Administration.Service.Model
{
    public class ProcPartComponentRuleDetail
    {
        public string InspectionStandardName { get; set; }
        public string WallThicknessRule { get; set; }
        public string AssetLocation { get; set; }
        public decimal MinimumThickness { get; set; }
        public decimal MaximumThickness { get; set; }
    }
}
