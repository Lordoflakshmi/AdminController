﻿using System;
using System.Collections.Generic;

namespace AMP.Administration.Service.Model
{
    public partial class UserLocation
    {
        public int UserLocationId { get; set; }
        public long? UserId { get; set; }
        public long? LocationId { get; set; }
        public bool? IsDefault { get; set; }
    }
}
