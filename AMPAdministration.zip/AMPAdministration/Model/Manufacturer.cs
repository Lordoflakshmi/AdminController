﻿using System;
using System.Collections.Generic;

namespace AMP.Administration.Service.Model
{
    public partial class Manufacturer
    {
        public int ManufacturerId { get; set; }
        public string Name { get; set; }
        public bool? IsActive { get; set; }
        public string Code { get; set; }
    }
}
