﻿using System;
using System.Collections.Generic;

namespace AMP.Administration.Service.Model
{
    public partial class InspectionType
    {
        public int InspectionTypeId { get; set; }
        public string Name { get; set; }
        public short? Precedence { get; set; }
    }
}
