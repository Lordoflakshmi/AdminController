﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AMP.Administration.Service.Model
{
   public  class AssetStatus
    {
        public AssetStatus()
        {
            InverseAlternateStatus = new HashSet<AssetStatus>();
        }

        public short AssetStatusId { get; set; }
        public string Name { get; set; }
        public bool? IsActive { get; set; }
        public long CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public long? UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public bool? CanBeInspected { get; set; }
        public bool? IsCustomerVisible { get; set; }
        public bool? IsCustomerUpdate { get; set; }
        public short? AlternateStatusId { get; set; }
        public bool IsInspectionPaused { get; set; }
        public bool IsMaxDaysEnabled { get; set; }

        public virtual AssetStatus AlternateStatus { get; set; }
        public virtual ICollection<AssetStatus> InverseAlternateStatus { get; set; }
    }
}
