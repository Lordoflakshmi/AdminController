﻿using System;
using System.Collections.Generic;

namespace AMP.Administration.Service.Model
{
    public partial class PartReference
    {
        public int PartReferenceId { get; set; }
        public string PartNumber { get; set; }
        public int? PartMasterId { get; set; }
    }
}
