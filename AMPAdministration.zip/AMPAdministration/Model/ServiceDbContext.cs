﻿using System;
using AMP.Administration.Service.Model;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace AMP.Administration.Service.Model
{
    public partial class ServiceDbContext : DbContext
    {
        public ServiceDbContext(DbContextOptions<ServiceDbContext> options)
            : base(options)
        {
        }

        public virtual DbSet<PartMaster> PartMaster { get; set; }
        public virtual DbSet<PartReference> PartReference { get; set; }
        public virtual DbSet<PartType> PartType { get; set; }
        public virtual DbSet<User> User { get; set; }
        public virtual DbSet<UserSession> UserSession { get; set; }
        public virtual DbSet<Location> Location { get; set; }
        public virtual DbSet<Feature> Feature { get; set; }
        public virtual DbSet<SecurityGroup> SecurityGroup { get; set; }
        public virtual DbSet<SecurityGroupFeature> SecurityGroupFeature { get; set; }
        public virtual DbSet<UserSecurityGroup> UserSecurityGroup { get; set; }
        public virtual DbSet<OrganizationalGroup> OrganizationalGroup { get; set; }
        public virtual DbSet<Manufacturer> Manufacturer { get; set; }
        public virtual DbSet<PressureRating> PressureRating { get; set; }
        public virtual DbSet<Service> Service { get; set; }
        public virtual DbSet<Size> Size { get; set; }
        public virtual DbSet<Style> Style { get; set; }
        public virtual DbSet<PartTypeConfigurationPressureRating> PartTypeConfigurationPressureRating { get; set; }
        public virtual DbSet<PartTypeConfigurationService> PartTypeConfigurationService { get; set; }
        public virtual DbSet<PartTypeConfigurationSize> PartTypeConfigurationSize { get; set; }
        public virtual DbSet<PartTypeConfigurationStyle> PartTypeConfigurationStyle { get; set; }
        public virtual DbSet<InspectionType> InspectionType { get; set; }
        public virtual DbSet<FeatureModule> FeatureModule { get; set; }
        public virtual DbSet<PartTypeConfigurationVariation> PartTypeConfigurationVariation { get; set; }
        public virtual DbSet<Variation> Variation { get; set; }
        public virtual DbSet<WorkOrderType> WorkOrderType { get; set; }
        public virtual DbSet<AssetStatus> AssetStatus { get; set; }
        public virtual DbSet<OrganizationHierarchy> OrganizationHierarchy { get; set; }
        public virtual DbSet<Gauge> Gauge { get; set; }
        public virtual DbSet<GaugeType> GaugeType { get; set; }
        public virtual DbSet<InspectionLevel> InspectionLevel { get; set; }
        public virtual DbSet<InspectionLevelType> InspectionLevelType { get; set; }
        public virtual DbSet<ProcPartComponentRuleDetail> ProcPartComponentRuleDetail { get; set; }
        public virtual DbSet<LocationHierarchy> LocationHierarchy { get; set; }
        public virtual DbSet<LocationHierarchyLevel> LocationHierarchyLevel { get; set; }
        public virtual DbSet<UserLocation> UserLocation { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {

            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("name=ConnectionStrings:WeirAMPDb");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<PartMaster>(entity =>
            {
                entity.HasIndex(e => e.ConfigurationId)
                    .HasName("IX_PartMaster_Configuration");

                entity.HasIndex(e => e.ConnectionId)
                    .HasName("IX_PartMaster_Connection");

                entity.HasIndex(e => e.InsideDiameterId)
                    .HasName("IX_PartMaster_InsideDiameter");

                entity.HasIndex(e => e.LengthId)
                    .HasName("IX_PartMaster_Length");

                entity.HasIndex(e => e.ManufacturerId)
                    .HasName("IX_PartMaster_Manufacturer");

                entity.HasIndex(e => e.OutsideDiameterId)
                    .HasName("IX_PartMaster_OutsideDiameter");

                entity.HasIndex(e => e.PartMasterId)
                    .HasName("UQ__PartMast__7582841287D9C8F5")
                    .IsUnique();

                entity.HasIndex(e => e.PartTypeId)
                    .HasName("IX_PartMaster_PartType");

                entity.HasIndex(e => e.PressureRatingId)
                    .HasName("IX_PartMaster_PressureRating");

                entity.HasIndex(e => e.SealTypeId)
                    .HasName("IX_PartMaster_SealType");

                entity.HasIndex(e => e.ServiceId)
                    .HasName("IX_PartMaster_Service");

                entity.HasIndex(e => e.SizeId)
                    .HasName("IX_PartMaster_Size");

                entity.HasIndex(e => e.StyleId)
                    .HasName("IX_PartMaster_Style");

                entity.HasIndex(e => e.UnionStyleId)
                    .HasName("IX_PartMaster_UnionStyle");

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DrawingName).HasMaxLength(500);

                entity.Property(e => e.IsQuarantined).HasDefaultValueSql("((0))");

                entity.Property(e => e.UpdatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.HasOne(d => d.PartType)
                    .WithMany(p => p.PartMaster)
                    .HasForeignKey(d => d.PartTypeId)
                    .HasConstraintName("FK_PartMaster_PartType");
            });

            modelBuilder.Entity<PartReference>(entity =>
            {
                entity.HasNoKey();

                entity.Property(e => e.PartNumber).HasMaxLength(100);

                entity.Property(e => e.PartReferenceId).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<PartType>(entity =>
            {
                entity.HasIndex(e => e.Name)
                    .HasName("UQ_PartType_Name")
                    .IsUnique();

                entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");

                entity.Property(e => e.Name)
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<User>(entity =>
            {
                entity.HasIndex(e => e.LoginUserName)
                    .HasName("U_LoginUserName")
                    .IsUnique();

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.EmailAddress)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FirstName)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.LastName)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.LocationId).HasMaxLength(100);

                entity.Property(e => e.LoginPassword)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LoginUserName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");
            });

            modelBuilder.Entity<UserSession>(entity =>
            {
                entity.HasNoKey();

                entity.Property(e => e.Id).HasDefaultValueSql("(newsequentialid())");
            });

            modelBuilder.Entity<Feature>(entity =>
            {
                entity.Property(e => e.Name)
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.ShortName)
                    .HasMaxLength(20)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<SecurityGroup>(entity =>
            {
                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");
            });

            modelBuilder.Entity<SecurityGroupFeature>(entity =>
            {
                entity.HasIndex(e => e.FeatureId)
                    .HasName("IX_SecurityGroupFeatureId");

                entity.HasIndex(e => e.SecurityGroupFeatureId)
                    .HasName("IX_SecurityGroupFeature");

                entity.HasIndex(e => e.SecurityGroupId)
                    .HasName("IX_SecurityGroupId");

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UpdatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.HasOne(d => d.Feature)
                    .WithMany(p => p.SecurityGroupFeature)
                    .HasForeignKey(d => d.FeatureId)
                    .HasConstraintName("FK_SecurityGroupFeature_Feature");

                entity.HasOne(d => d.SecurityGroup)
                    .WithMany(p => p.SecurityGroupFeature)
                    .HasForeignKey(d => d.SecurityGroupId)
                    .HasConstraintName("FK_SecurityGroupFeature_SecurityGroup");
            });

            modelBuilder.Entity<UserSecurityGroup>(entity =>
            {
                entity.HasIndex(e => e.SecurityGroupId)
                    .HasName("IX_UserSecurityGroupId");

                entity.HasIndex(e => e.UserId)
                    .HasName("IX_UserSecurityGroupUserId");

                entity.HasIndex(e => e.UserSecurityGroupId)
                    .HasName("IX_UserSecurityGroup");

                entity.HasOne(d => d.SecurityGroup)
                    .WithMany(p => p.UserSecurityGroup)
                    .HasForeignKey(d => d.SecurityGroupId)
                    .OnDelete(DeleteBehavior.Cascade)
                    .HasConstraintName("FK_tblUserSecurityGroup_tblSecurityGroup");
            });

            modelBuilder.Entity<InspectionType>(entity =>
            {
                entity.Property(e => e.Name)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<FeatureModule>(entity =>
            {
                entity.HasKey(e => e.ModuleId);

                entity.Property(e => e.ModuleId).HasColumnName("ModuleID");
            });

            modelBuilder.Entity<WorkOrderType>(entity =>
            {
                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.IsPumpWorkOrderType)
                    .IsRequired()
                    .HasDefaultValueSql("('FALSE')");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(300);

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            });

            modelBuilder.Entity<OrganizationHierarchy>(entity =>
            {
                entity.HasKey(e => e.OrgGroupId);

                entity.Property(e => e.OrgGroupId).ValueGeneratedNever();
            });

            modelBuilder.Entity<InspectionLevel>(entity =>
            {
                entity.Property(e => e.CreatedBy).HasDefaultValueSql("((23897))");

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");

                entity.Property(e => e.Name)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            });

            modelBuilder.Entity<InspectionLevelType>(entity =>
            {
                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            });

            modelBuilder.Entity<ProcPartComponentRuleDetail>(entity =>
                entity.HasNoKey()
            );

            modelBuilder.Entity<LocationHierarchy>(entity =>
            {
                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.Name)
                    .HasMaxLength(150)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");
            });

            modelBuilder.Entity<LocationHierarchyLevel>(entity =>
            {
                entity.Property(e => e.Name)
                    .HasMaxLength(10)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<UserLocation>(entity =>
            {
                entity.HasIndex(e => e.LocationId)
                    .HasName("IX_UserLocationId");

                entity.HasIndex(e => e.UserId)
                    .HasName("IX_UserId");

                entity.Property(e => e.IsDefault).HasDefaultValueSql("((0))");
            });
            modelBuilder.Entity<Location>(entity =>
            {
                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IsNotificationApplicable).HasDefaultValueSql("('FALSE')");

                entity.Property(e => e.LocationName).HasMaxLength(50);

                entity.Property(e => e.UpdatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
