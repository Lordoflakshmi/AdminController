﻿using System;
using System.Collections.Generic;

namespace AMP.Administration.Service.Model
{
    public partial class PartMaster
    {
        public int ManufacturerId { get; set; }
        public int PartTypeId { get; set; }
        public long CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public long? UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public int? ConfigurationId { get; set; }
        public int? ConnectionId { get; set; }
        public int? InsideDiameterId { get; set; }
        public int? LengthId { get; set; }
        public int? OutsideDiameterId { get; set; }
        public int? PressureRatingId { get; set; }
        public int? SealTypeId { get; set; }
        public int? ServiceId { get; set; }
        public int? SizeId { get; set; }
        public int? StyleId { get; set; }
        public int? UnionStyleId { get; set; }
        public int PartMasterId { get; set; }
        public int? VariationId { get; set; }
        public bool? IsQuarantined { get; set; }
        public byte[] DrawingImage { get; set; }
        public string DrawingName { get; set; }

        public virtual PartType PartType { get; set; }
    }
}
