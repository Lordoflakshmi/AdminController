﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AMP.Administration.Service.Model
{
   public class PartType
    {
        public PartType()
        {
            PartMaster = new HashSet<PartMaster>();
        }

       
        public int PartTypeId { get; set; }
        public string Name { get; set; }
        public bool? IsActive { get; set; }
        public bool? IsAssemblyRequired { get; set; }
        public bool? IsAmppartType { get; set; }
        public bool? IsPumpPartType { get; set; }

        public virtual ICollection<PartMaster> PartMaster { get; set; }
    }
}
