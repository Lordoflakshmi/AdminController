﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace AMP.Administration.Service.Model
{
    public partial class PartTypeConfigurationPressureRating
    {
        [Key]
        public int ConfigurationPressureId { get; set; }
        public int? PartTypeId { get; set; }
        public int? PressureRatingId { get; set; }
    }

    
   
}
