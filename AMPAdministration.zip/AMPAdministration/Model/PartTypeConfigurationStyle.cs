﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace AMP.Administration.Service.Model
{
    public partial class PartTypeConfigurationStyle
    {
        [Key]
        public int ConfigurationStyleId { get; set; }
        public int? PartTypeId { get; set; }
        public int? StyleId { get; set; }
    }
}
