﻿using AMP.Administration.Service.DTO.Response;
using System.Threading.Tasks;

namespace AMP.Administration.Contract
{
    public interface IPart
    {
        public string GetPartTypeByPartNumber(string number);
        public Response GetPartDetailsByPartNumber(string PartNumber);
        Task<Response> GetAllPartType();
        Task<Response> GetPartConfigurations(long PartTypeId);
        Task<Response> GetAssetDescriptionByPartNumbers(string[]  PartNumebrs);
        Task<Response> GetManufacturerNameById(int[] ids);
        Task<Response> GetPartTypeByIds(int[] PartTypeIds);
        Task<Response> GetPartDetailsByIds(string[] ids);
        Task<Response> GetComponentRuleDetailsForClearanceOrTorqueAsync(string partNumber, int customerId, int manufacturerId);
    }
}
