﻿using AMP.Administration.Service.DTO.Response;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AMP.Administration.Service.ServiceContract
{
    public interface IPartImage
    {
        public Task<Response> GetPictureByIdsAsync(int PartTypeId, int PressureRatingId, int ServiceId, int SizeId, int StyleId, int VariationId);
    }
}
