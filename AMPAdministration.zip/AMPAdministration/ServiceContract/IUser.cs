﻿using AMP.Administration.Service.DTO.Response;
using AMP.Administration.Service.DTOs.Responses;
using AMP.Administration.Service.Model;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AMP.Administration.Service.ServiceContract
{
    public interface IUser
    {
        public Task<UserResponse> GetUserDetailsAsync(Guid claim);

        public Task<Response> GetUserNamesAsync(long[] UserIds);
        public Task<Response> GetCustomerUserAsync(long OrgGrpIds);
    }
}
