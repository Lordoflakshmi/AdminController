﻿using AMP.Administration.Service.DTO.Response;
using AMP.Administration.Service.Model;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AMP.Administration.ServiceContract
{
    public interface ILocation
    {
        Task<Response> GetLocations(long requestedById);
        Task<Response> GetLocationsName(long [] LocaitonIds);
        Task<Response> GetTransferLocationsAsync(long serviceCenterId, int locationHierarchyLevelId, long requestedById);
        Task<bool> GetIsNotificaionApplicable(long LocaitonIds);
    }
}
