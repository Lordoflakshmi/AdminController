﻿using AMP.Administration.Service.DTO.Response;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AMP.Administration.Service.ServiceContract
{
    public interface IWorkOrder
    {
        public Task<Response> GetWorkOrderType();
    }
}
