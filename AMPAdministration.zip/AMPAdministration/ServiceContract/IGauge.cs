﻿using AMP.Administration.Service.DTO.Response;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AMP.Administration.Service.ServiceContract
{
   public interface IGauge
    {
        public Task<Response> GetGaugesByServiceCenterId( int GuageId, long ServiceCenterId);
        public Task<Response> GetGaugeTypeByGaugeIdAsync(int[] gaugeIds);
        
    }
}
