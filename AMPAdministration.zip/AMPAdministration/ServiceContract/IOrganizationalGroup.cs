﻿using AMP.Administration.Service.DTO.Response;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AMP.Administration.Service.ServiceContract
{
    public interface IOrganizationalGroup
    {
        Task<Response> GetOrganizationGroups(int levelId,int Id, string requestedById);
        Task<Response> GetOrganizationalGroupHierarchy(string requestedById);
        public Task<Response> GetOrganizationalGroupHierarchyNameByIdAsync(long id);
        public Task<Response> GetOrganizationalGroupHierarchyNameByIdAsync(string[] OrganizationGrupIds);
        Task<Response> GetOrganizationsName(long[] OrganizationsIds);
        Task<Response> GetOrganizationParentGroup(long[] OrganizationsIds);
    }
}
