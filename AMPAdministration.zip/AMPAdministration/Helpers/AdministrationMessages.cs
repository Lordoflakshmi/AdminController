﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AMP.Administration.Service.Helpers
{
    public static class AdministrationMessages
    {
        public const string GetSuccess = "Retreived Successfully.";
        public const string PictureUnavailable = "Picture Is Not Available.";
        public const string InvalidData = "Please Enter valid Data.";
    }
}
